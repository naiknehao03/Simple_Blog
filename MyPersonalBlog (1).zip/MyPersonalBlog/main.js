// Wait until the entire DOM is loaded before executing the script
document.addEventListener('DOMContentLoaded', function() {

    // Get references to the form and the container where blog posts will be displayed
    const form = document.getElementById('blogForm');
    const blogPosts = document.getElementById('blog-posts');
  
    // Add an event listener to the form to handle form submission
    form.addEventListener('submit', function(event) {
        // Prevent the default form submission behavior (page reload)
        event.preventDefault();
  
        // Get and trim the values from the input fields
        const title = document.getElementById('title').value.trim();
        const author = document.getElementById('author').value.trim();
        const date = document.getElementById('date').value.trim();
        const content = document.getElementById('content').value.trim();
        const imageInput = document.getElementById('image');
        const imageFile = imageInput.files[0];
  
        // Check if any of the required fields are empty
        if (title === '' || author === '' || date === '' || content === '') {
            // Alert the user if any field is empty and exit the function
            alert('Please fill in all fields.');
            return;
        }
  
        // Create elements for the new blog post
        const article = document.createElement('article');
        const h2 = document.createElement('h2');
        const p = document.createElement('p');
        const footer = document.createElement('footer');
        const small = document.createElement('small');
        small.style.color = "#c1c1c1;"; // Set the color of the small text
        const img = document.createElement('img');
  
        // Set the text content for the title, content, and footer
        h2.textContent = title;
        p.textContent = content;
        small.textContent = `By ${author} on ${date}`;
  
        // Append the footer elements
        footer.appendChild(small);
  
        // If an image file is selected, read it and set it to the img element
        if (imageFile) {
            const reader = new FileReader();
            reader.onload = function(e) {
                img.src = e.target.result; // Set the image source to the file data
                img.alt = title; // Set the image alt text
                article.appendChild(img); // Append the image to the article
                appendArticleToBlogPosts(article, h2, p, footer); // Append the complete article
            }
            reader.readAsDataURL(imageFile); // Read the file as a data URL
        } else {
            // If no image is selected, directly append the article elements
            appendArticleToBlogPosts(article, h2, p, footer);
        }
  
        // Reset the form to clear all input fields
        form.reset();
    });
  
    // Function to append the article elements to the blog posts container
    function appendArticleToBlogPosts(article, h2, p, footer) {
        article.appendChild(h2); // Append the title
        article.appendChild(p); // Append the content
        article.appendChild(footer); // Append the footer
        blogPosts.appendChild(article); // Append the complete article to the blog posts container
    }
});
